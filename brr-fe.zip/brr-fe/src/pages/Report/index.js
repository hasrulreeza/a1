import React from "react";
import ReactDOM from "react-dom";
import Button from "@material-ui/core/Button";
import Table from "./reportTable";


function reportTable() {
  return <Table />;
}

export default reportTable;
