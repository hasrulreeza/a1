import React from "react";
import ReactDOM from "react-dom";
import Button from "@material-ui/core/Button";

class PreviewPDF extends React.Component {
    preview(pdfURL) {
    // fake server request, getting the file url as response
    // setTimeout(() => {
      const response = {
        file:pdfURL
      };
      // server sent the url to the file!
      // now, let's download:
       window.location.href = response.file;
      // you could also do:
    //   window.open(response.file);
    // }, 100);
    
  }
  render() {
    return (
   <div>
        <Button color="primary" onClick={this.preview.bind(this,this.props.pdfURL)}>
        {this.props.reportName}
        </Button>
      </div>
    );
  }
}

export default PreviewPDF;
